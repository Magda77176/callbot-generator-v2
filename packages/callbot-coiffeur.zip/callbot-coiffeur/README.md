# 🎤 CallBot Léa — Assistant Vocal Salon de Coiffure & Beauté

Assistant vocal IA automatisé pour salon de coiffure & beauté.

## 📋 Vue d'ensemble

**Léa** gère automatiquement les appels entrants, collecte les informations clients et confirme les rendez-vous de manière conversationnelle.

## 🚀 Caractéristiques

### Services disponibles
- **Coupe + Brushing** — €35 (45 min)
- **Coloration** — €65 (90 min)

### Stack technique
- **Platform:** Vapi AI
- **LLM:** OpenAI GPT-4o-mini  
- **Voix:** Google Cloud français
- **Intégration:** WordPress plugin

## 🛠 Configuration

### 1. Variables d'environnement
```bash
export VAPI_API_KEY="your-vapi-key"
export WEBHOOK_URL="https://yourdomain.com/webhook"
export WEBHOOK_SECRET="your-secret"
```

### 2. Installation WordPress
1. Télécharger le plugin depuis `wordpress-plugin/`
2. Activer dans WordPress Admin
3. Configurer les clés API
4. Tester l'intégration

### 3. Déploiement webhook
```bash
node webhook-handler.js
```

## 📊 Tests

```bash
node test-integration.js
```

## 📞 Usage

Le CallBot suit un flux strict en 5 étapes :
1. **Accueil** — Salutation et présentation
2. **Triage** — Détection d'urgences
3. **Besoin** — Identification du service
4. **Collecte** — Informations client
5. **Confirmation** — Validation finale

---

**Généré par CallBot Generator V2 — Format Mindy**
