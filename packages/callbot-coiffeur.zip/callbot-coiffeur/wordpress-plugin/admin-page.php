<div class="wrap">
    <h1>🤖 CallBot Léa</h1>
    
    <form method="post" action="admin-ajax.php">
        <input type="hidden" name="action" value="callbot_save_settings">
        
        <table class="form-table">
            <tr>
                <th><label for="vapi_key">Clé API Vapi</label></th>
                <td><input type="text" name="vapi_key" value="<?php echo esc_attr(get_option('callbot_vapi_key')); ?>" class="regular-text" /></td>
            </tr>
            <tr>
                <th><label for="assistant_id">Assistant ID</label></th>
                <td><input type="text" name="assistant_id" value="<?php echo esc_attr(get_option('callbot_assistant_id')); ?>" class="regular-text" /></td>
            </tr>
            <tr>
                <th><label for="enabled">Activer CallBot</label></th>
                <td><input type="checkbox" name="enabled" <?php checked(get_option('callbot_enabled')); ?> /></td>
            </tr>
        </table>
        
        <?php submit_button(); ?>
    </form>
</div>