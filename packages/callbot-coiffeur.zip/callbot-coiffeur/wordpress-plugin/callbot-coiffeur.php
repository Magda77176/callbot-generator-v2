<?php
/**
 * Plugin Name: CallBot Léa
 * Description: Assistant vocal IA pour Salon de Coiffure & Beauté
 * Version: 2.0.0
 * Author: CallBot Generator V2
 */

if (!defined('ABSPATH')) exit;

class CallBotLéa {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_menu', array($this, 'admin_menu'));
        add_action('wp_ajax_callbot_save_settings', array($this, 'save_settings'));
        add_action('wp_ajax_nopriv_callbot_webhook', array($this, 'handle_webhook'));
        add_action('wp_ajax_callbot_webhook', array($this, 'handle_webhook'));
    }
    
    public function init() {
        // Initialisation du plugin
    }
    
    public function enqueue_scripts() {
        if (get_option('callbot_enabled', false)) {
            wp_enqueue_script(
                'vapi-sdk',
                'https://cdn.jsdelivr.net/gh/VapiAI/html-script-tag@latest/dist/assets/index.js',
                array(),
                '1.0.0',
                true
            );
            
            wp_add_inline_script('vapi-sdk', $this->get_vapi_config());
        }
    }
    
    public function admin_menu() {
        add_menu_page(
            'CallBot Léa',
            '🤖 Léa',
            'manage_options',
            'callbot-coiffeur',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        // Interface d'administration
        include 'admin-page.php';
    }
    
    private function get_vapi_config() {
        $api_key = get_option('callbot_vapi_key', '');
        $assistant_id = get_option('callbot_assistant_id', '');
        
        return "
        window.addEventListener('load', function() {
            if (window.vapiSDK) {
                window.vapiSDK.run({
                    apiKey: '{$api_key}',
                    assistant: '{$assistant_id}',
                    config: {
                        position: 'bottom-right',
                        offset: '24px',
                        width: '80px',
                        height: '80px'
                    }
                });
            }
        });
        ";
    }
    
    public function handle_webhook() {
        $input = file_get_contents('php://input');
        $data = json_decode($input, true);
        
        if ($data && $data['event'] === 'call.completed') {
            // Traiter les données de l'appel
            $this->save_call_data($data);
        }
        
        wp_die(json_encode(['status' => 'success']));
    }
    
    private function save_call_data($data) {
        // Sauvegarder en base WordPress
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'callbot_calls';
        
        $wpdb->insert(
            $table_name,
            array(
                'call_id' => $data['callId'],
                'sector' => 'coiffeur',
                'first_name' => $data['data']['firstName'],
                'last_name' => $data['data']['lastName'],
                'phone' => $data['data']['phoneNumber'],
                'service' => $data['data']['service'],
                'appointment_date' => $data['data']['appointmentDate'],
                'appointment_time' => $data['data']['appointmentTime'],
                'created_at' => current_time('mysql')
            )
        );
    }
}

new CallBotLéa();
