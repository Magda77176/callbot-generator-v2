# 🚀 Guide de déploiement — callbot-dentaire

## Prérequis
- Compte Vapi AI (https://vapi.ai)
- Clé API Vapi
- Serveur pour webhook (Node.js recommandé)
- WordPress (optionnel, pour plugin)

## Étapes de déploiement

### 1. Configuration Vapi
```bash
# Variables d'environnement
export VAPI_API_KEY="your-vapi-public-key"
export VAPI_PRIVATE_KEY="your-vapi-private-key"
export WEBHOOK_URL="https://yourdomain.com/webhook"
export WEBHOOK_SECRET="your-secret"
```

### 2. Créer l'assistant sur Vapi
```bash
# Upload du system prompt
curl -X POST "https://api.vapi.ai/assistant" \
  -H "Authorization: Bearer ${VAPI_PRIVATE_KEY}" \
  -H "Content-Type: application/json" \
  -d @example-config.json
```

### 3. Déployer le webhook
```bash
# Installer dépendances
npm install express mysql2 crypto

# Lancer le webhook handler
node webhook-handler.js
```

### 4. WordPress (optionnel)
1. Copier le dossier `wordpress-plugin/` dans `wp-content/plugins/`
2. Activer le plugin dans WordPress Admin
3. Configurer les clés API

### 5. Tests
```bash
# Tests d'intégration
node test-integration.js
```

## Configuration spécifique — dentaire

### Variables à personnaliser
- `{{restaurant_name}}` → Nom de votre restaurant
- `{{specialites}}` → Vos spécialités
- `{{horaires_ouverture}}` → Vos horaires
- `{{telephone}}` → Votre numéro
- `{{adresse}}` → Votre adresse

### Services configurés
Voir `example-config.json` section `services` pour modifier les prix/durées.

## Support

- Documentation Vapi: https://docs.vapi.ai
- Issues: GitHub repository
- Email: support@yourdomain.com

---
**Généré par CallBot Generator V2**
