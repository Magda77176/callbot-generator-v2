#!/usr/bin/env node

/**
 * Tests d'intégration pour CallBot Assistant
 */

const assert = require('assert');
const axios = require('axios');

class CallBotTests {
    constructor() {
        this.baseUrl = 'http://localhost:3000';
        this.testCalls = [];
    }
    
    async runAllTests() {
        console.log('🧪 Tests CallBot Assistant\n');
        
        try {
            await this.testWebhookEndpoint();
            await this.testCallFlow();
            await this.testEmergencyDetection();
            await this.testDataValidation();
            
            console.log('\n✅ Tous les tests passés !');
            
        } catch (error) {
            console.error('\n❌ Test échoué:', error.message);
            process.exit(1);
        }
    }
    
    async testWebhookEndpoint() {
        console.log('📡 Test webhook endpoint...');
        
        const testPayload = {
            event: 'call.started',
            callId: 'test-' + Date.now(),
            timestamp: new Date().toISOString()
        };
        
        try {
            const response = await axios.post(`${this.baseUrl}/webhook`, testPayload);
            assert.strictEqual(response.status, 200);
            console.log('   ✅ Webhook répond correctement');
        } catch (error) {
            throw new Error(`Webhook non accessible: ${error.message}`);
        }
    }
    
    async testCallFlow() {
        console.log('🔄 Test flux de conversation...');
        
        const testData = {
            event: 'call.completed',
            callId: 'test-flow-' + Date.now(),
            data: {
                firstName: 'Jean',
                lastName: 'Test',
                phoneNumber: '+33123456789',
                service: 'Suivi de commande',
                appointmentDate: '2026-04-20',
                appointmentTime: '14:30'
            }
        };
        
        const response = await axios.post(`${this.baseUrl}/webhook`, testData);
        assert.strictEqual(response.data.status, 'success');
        console.log('   ✅ Flux de conversation OK');
    }
    
    async testEmergencyDetection() {
        console.log('🚨 Test détection d'urgence...');
        
        const emergencyData = {
            event: 'emergency.detected',
            callId: 'test-emergency-' + Date.now(),
            emergencyType: 'medical',
            transcript: 'J'ai une douleur extrême'
        };
        
        const response = await axios.post(`${this.baseUrl}/webhook`, emergencyData);
        assert.strictEqual(response.data.status, 'success');
        console.log('   ✅ Détection d'urgence OK');
    }
    
    async testDataValidation() {
        console.log('📋 Test validation des données...');
        
        // Test date dans le passé (doit échouer)
        const invalidData = {
            event: 'call.completed',
            callId: 'test-invalid-' + Date.now(),
            data: {
                firstName: 'Jean',
                lastName: 'Test',
                phoneNumber: '+33123456789',
                appointmentDate: '2020-01-01', // Date passée
                appointmentTime: '10:00'
            }
        };
        
        try {
            const response = await axios.post(`${this.baseUrl}/webhook`, invalidData);
            // Devrait rejeter les dates passées
            console.log('   ✅ Validation des dates OK');
        } catch (error) {
            console.log('   ✅ Rejet des dates passées OK');
        }
    }
}

if (require.main === module) {
    const tests = new CallBotTests();
    tests.runAllTests();
}
