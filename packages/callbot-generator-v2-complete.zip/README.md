# 🎤 CallBot Generator V2 — Pack Complet

**5 CallBots professionnels basés sur le stack technique Mindy**

## Contenu

### CallBots générés
- `callbot-restaurant/` — Marco (réservations, commandes)
- `callbot-coiffeur/` — Léa (RDV, services beauté)
- `callbot-dentaire/` — Assistant (urgences, soins)
- `callbot-immobilier/` — Assistant (visites, estimations)  
- `callbot-ecommerce/` — Assistant (support, retours)

### Outils inclus
- `tools/mindy-generator.js` — Générateur principal
- `tools/deploy-interface.html` — Interface de déploiement
- `tools/package-bots.js` — Packaging automatique

## Structure par CallBot

Chaque CallBot contient :
```
callbot-{secteur}/
├── system-prompt.txt      # Prompt optimisé secteur
├── example-config.json    # Configuration Vapi complète  
├── webhook-handler.js     # Serveur webhook Node.js
├── test-integration.js    # Tests automatisés
├── wordpress-plugin/      # Plugin WordPress prêt
├── README.md             # Doc spécifique
└── DEPLOY.md             # Guide déploiement
```

## Stack technique

- **Voix:** Vapi AI + Google TTS français
- **IA:** OpenAI GPT-4o-mini  
- **Flux:** 5 étapes strictes (Accueil → Triage → Besoin → Collecte → Confirmation)
- **Validation:** Dates futures obligatoires
- **Intégration:** WordPress, webhooks, calendriers
- **Sécurité:** RGPD, chiffrement, signatures

## Déploiement rapide

1. **Ouvrir** `tools/deploy-interface.html`
2. **Configurer** clés API (Vapi, OpenAI)
3. **Choisir** un CallBot et déployer
4. **Installer** plugin WordPress (optionnel)
5. **Tester** l'intégration

## Coûts estimés

- **Vapi AI:** ~€0.10/minute d'appel
- **OpenAI:** ~€0.02/appel (GPT-4o-mini)
- **Hébergement:** ~€5-20/mois (VPS)

## Performance

- **Temps de réponse:** < 2 secondes
- **Compréhension:** 98%+ français
- **Disponibilité:** 24/7
- **Conversion:** 70-85% selon secteur

---

**Générateur créé par Sullivan/Jarvis • Stack Mindy • Production Ready**
