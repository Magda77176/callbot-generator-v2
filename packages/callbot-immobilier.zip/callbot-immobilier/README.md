# 🎤 CallBot Assistant — Assistant Vocal Agence Immobilière

Assistant vocal IA automatisé pour agence immobilière.

## 📋 Vue d'ensemble

**Assistant** gère automatiquement les appels entrants, collecte les informations clients et confirme les rendez-vous de manière conversationnelle.

## 🚀 Caractéristiques

### Services disponibles
- **Estimation gratuite** — €0 (30 min)
- **Visite pour vente** — €0 (60 min)
- **Recherche d'achat** — €0 (45 min)
- **Conseil investissement** — €150 (90 min)

### Stack technique
- **Platform:** Vapi AI
- **LLM:** OpenAI GPT-4o-mini  
- **Voix:** Google Cloud français
- **Intégration:** WordPress plugin

## 🛠 Configuration

### 1. Variables d'environnement
```bash
export VAPI_API_KEY="your-vapi-key"
export WEBHOOK_URL="https://yourdomain.com/webhook"
export WEBHOOK_SECRET="your-secret"
```

### 2. Installation WordPress
1. Télécharger le plugin depuis `wordpress-plugin/`
2. Activer dans WordPress Admin
3. Configurer les clés API
4. Tester l'intégration

### 3. Déploiement webhook
```bash
node webhook-handler.js
```

## 📊 Tests

```bash
node test-integration.js
```

## 📞 Usage

Le CallBot suit un flux strict en 5 étapes :
1. **Accueil** — Salutation et présentation
2. **Triage** — Détection d'urgences
3. **Besoin** — Identification du service
4. **Collecte** — Informations client
5. **Confirmation** — Validation finale

---

**Généré par CallBot Generator V2 — Format Mindy**
