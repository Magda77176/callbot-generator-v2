#!/usr/bin/env node

/**
 * Webhook Handler pour CallBot Marco
 */

const express = require('express');
const crypto = require('crypto');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json());

// Configuration
const config = {
    port: process.env.PORT || 3000,
    webhookSecret: process.env.WEBHOOK_SECRET,
    dbHost: process.env.DB_HOST || 'localhost',
    dbUser: process.env.DB_USER || 'root',
    dbPassword: process.env.DB_PASSWORD,
    dbName: process.env.DB_NAME || 'callbot_restaurant'
};

// Vérification signature webhook
function verifyWebhookSignature(payload, signature, secret) {
    const expectedSignature = crypto
        .createHmac('sha256', secret)
        .update(payload)
        .digest('hex');
    
    return signature === `sha256=${expectedSignature}`;
}

// Handler principal
app.post('/webhook', async (req, res) => {
    try {
        const signature = req.headers['x-vapi-signature'];
        const payload = JSON.stringify(req.body);
        
        if (!verifyWebhookSignature(payload, signature, config.webhookSecret)) {
            return res.status(401).json({ error: 'Invalid signature' });
        }
        
        const data = req.body;
        
        switch (data.event) {
            case 'call.started':
                await handleCallStarted(data);
                break;
                
            case 'call.completed':
                await handleCallCompleted(data);
                break;
                
            case 'call.failed':
                await handleCallFailed(data);
                break;
                
            case 'emergency.detected':
                await handleEmergency(data);
                break;
        }
        
        res.json({ status: 'success' });
        
    } catch (error) {
        console.error('Webhook error:', error);
        res.status(500).json({ error: error.message });
    }
});

async function handleCallStarted(data) {
    console.log(`📞 Appel démarré: ${data.callId}`);
    
    const db = await mysql.createConnection(config);
    await db.execute(
        'INSERT INTO calls (call_id, status, started_at) VALUES (?, ?, NOW())',
        [data.callId, 'started']
    );
    await db.end();
}

async function handleCallCompleted(data) {
    console.log(`✅ Appel terminé: ${data.callId}`);
    
    const callData = data.data;
    const db = await mysql.createConnection(config);
    
    await db.execute(`
        UPDATE calls SET 
            status = 'completed',
            first_name = ?,
            last_name = ?,
            phone = ?,
            service = ?,
            appointment_date = ?,
            appointment_time = ?,
            completed_at = NOW()
        WHERE call_id = ?
    `, [
        callData.firstName,
        callData.lastName, 
        callData.phoneNumber,
        callData.service,
        callData.appointmentDate,
        callData.appointmentTime,
        data.callId
    ]);
    
    await db.end();
    
    // Intégrations supplémentaires (email, calendrier, etc.)
    await sendNotifications(callData);
}

async function handleCallFailed(data) {
    console.log(`❌ Appel échoué: ${data.callId}`);
    
    const db = await mysql.createConnection(config);
    await db.execute(
        'UPDATE calls SET status = ?, failed_at = NOW() WHERE call_id = ?',
        ['failed', data.callId]
    );
    await db.end();
}

async function handleEmergency(data) {
    console.log(`🚨 URGENCE DÉTECTÉE: ${data.callId}`);
    
    // Alertes immédiates
    // TODO: Email/SMS d'urgence
}

async function sendNotifications(callData) {
    // TODO: Envoyer email de confirmation
    // TODO: Créer événement calendrier
    // TODO: SMS de rappel
}

app.listen(config.port, () => {
    console.log(`🎤 Webhook CallBot Marco sur port ${config.port}`);
});
